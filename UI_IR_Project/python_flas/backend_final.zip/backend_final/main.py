from flask import Flask, render_template, request,redirect,jsonify
# from model import Query_Processing,MainIndex,city_index,state_index,category_index
import urllib.request
from urllib.error import HTTPError
import imghdr
import pandas as pd
import requests
import json
from flask_cors import CORS
import pickle as pkl
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.models import Model
base_model = VGG16(weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('fc1').output)
ft_dict = dict()
import json
from scipy.spatial.distance import cosine
import operator
from operator import itemgetter


import numpy as np
from PIL import Image
from operator import itemgetter

from model import Query_Processing,all_places, sub_cat_index,category_index,state_index, city_index, MainIndex,distance_index



from model import Query_Processing,all_places, sub_cat_index,category_index,state_index, city_index, MainIndex,distance_index
travel_dataframe = pd.read_csv('travel_dataset_v4.csv')
my_list = [    'imageUrls_0', 'imageUrls_1', 'imageUrls_2', 'imageUrls_3', 'imageUrls_4',   
                'imageUrls_5', 'imageUrls_6', 'imageUrls_7', 'imageUrls_8', 'imageUrls_9',   
                  'imageUrls_10', 'imageUrls_11', 'imageUrls_12', 'imageUrls_13', 'imageUrls_14', 
                        'imageUrls_15', 'imageUrls_16', 'imageUrls_17', 'imageUrls_18', 'imageUrls_19',   
                          'categories_0', 'categories_1', 'categories_2', 'categories_3', 'categories_4',  
                              'categories_5', 'categories_6','SubcategoryName','feature_set','neighborhood','peopleAlsoSearch_0_title',
                              'peopleAlsoSearch_1_title','peopleAlsoSearch_2_title','peopleAlsoSearch_3_title','peopleAlsoSearch_4_title',
                              'postalCode', 'location_lat', 'location_lng','street']

print(travel_dataframe.columns)
app = Flask(__name__, template_folder='templates')
CORS(app, origins='http://localhost:3000')

def is_valid_url(url):
    try:
        response = requests.get(url)
        return response.status_code == 200
    except:
        return False


@app.route('/api/data', methods=['GET'])
def get_data():
    query = request.args.get('query')
    
    print(query)
    s = Query_Processing()
    result = s.searchQuery(query)

    result = result[:25]
    print(result)
    result = result.drop(my_list,axis = 1)
    temp = travel_dataframe.drop(my_list,axis = 1)

    # travel_dataframe = travel_dataframe.iloc[result['place_id']]
    temp = temp.loc[temp['place_id'].isin(result['place_id'])]
    temp = temp.loc[result.index]
    temp = temp.drop_duplicates(subset='title')

    
    print(temp)
    data = temp.to_dict(orient='records')
    json_data = json.dumps(data)
    return jsonify(data)


@app.route('/api/nearby_data', methods=['GET'])
def nearby_places():
    query = request.args.get('query')
    print(query)
    s = Query_Processing()
    s.get_indices()
    query  = query.lower()
    result = s.find_nearby_places(query)
    print(result)
    result = result[:6] #taking starting five nearby places
    result = result.drop(my_list,axis = 1)

    filtered_df = travel_dataframe[travel_dataframe['title'].str.lower().isin([r.lower() for r in result])]

    filtered_df = filtered_df.drop(my_list,axis = 1)
    data = filtered_df.to_dict(orient='records')
    json_data = json.dumps(data)
    return jsonify(data)
    

# df = pd.read_csv('Travel_dataset_final_V3.csv')

# Load the required pickle files and CSV file
ft_dict = pkl.load(open('feature_dict.pkl', 'rb'))
train = pkl.load(open('train_dict.pkl', 'rb'))
df = pd.read_csv('Travel_dataset_final_V3.csv')

# Define the API endpoint
@app.route('/api/get_similar_images', methods=['POST'])
def get_similar_images():
    # Get the uploaded image file

    img = request.files['image']
    print(img)
    from PIL import Image

    # img_file = "/content/Tourist_attraction_5718.jpg"       # write the image file name
    img = Image.open(img)
    img = img.resize((224, 224))

    # img.show()
    # Call the get_sim_img function
    res_df = get_sim_img(img)
    res_df = res_df[:30]
    res_df = res_df.drop(my_list,axis = 1)
    temp = travel_dataframe.drop(my_list,axis = 1)

    # travel_dataframe = travel_dataframe.iloc[res_df['place_id']]
    temp = temp.loc[temp['place_id'].isin(res_df['place_id'])]
    temp = temp.loc[res_df.index]
    temp = temp.drop_duplicates(subset='title')

    # Convert the output DataFrame to JSON and return it
    return jsonify(temp.to_dict(orient='records'))

def extract(img):
  x = image.img_to_array(img)
  x = np.expand_dims(x, axis=0)
  x = preprocess_input(x)
  feature = model.predict(x)[0]
  return feature / np.linalg.norm(feature)

# def get_sim_img(img):
#     res = []
#     ft = extract(img)
#     for fl, train_ft in ft_dict.items():
#         sim = 1 - cosine(train_ft[1], ft)
#         res.append([train_ft[0], train[fl][1], sim, train[fl][2]])
#     res.sort(key=operator.itemgetter(2, 3), reverse=True)
#     if len(res) > 50:
#         pids = [res[i][0] for i in range(50)]
#         res = [[res[i][0], res[i][1]] for i in range(50)]
#     else:
#         pids = [res[i][0] for i in range(len(res))]
#         res = [[res[i][0], res[i][1]] for i in range(len(res))]
#     df2 = travel_dataframe.loc[travel_dataframe['place_id'].isin(pids)]
#     res_df = df2[['place_id', 'title', 'city', 'state', 'description', 'imageUrls_0']].copy()
#     for i in range(len(res_df)):
#         res_df['imageUrls_0'][i] = res[i][1]
#     return res_df

def get_sim_img(img):
    res = []
    ft = extract(img)
    for fl, train_ft in ft_dict.items():
        sim = 1 - cosine(train_ft[1], ft)
        res.append([train_ft[0], train[fl][1], sim, train[fl][2]])
    res.sort(key=operator.itemgetter(2, 3), reverse=True)
    if len(res) > 50:
        pids = [res[i][0] for i in range(50)]
        res = [[res[i][0], res[i][1]] for i in range(50)]
    else:
        pids = [res[i][0] for i in range(len(res))]
        res = [[res[i][0], res[i][1]] for i in range(len(res))]
    df2 = travel_dataframe.loc[travel_dataframe['place_id'].isin(pids)]
    # res_df = df2[['place_id', 'title', 'city', 'state', 'description', 'imageUrls_0']].copy()
    # res_df.loc[:, 'imageUrls_0'] = [res[i][1] for i in range(len(res_df))]
    return df2


# # Define the API endpoint
# @app.route('/api/get_similar_images', methods=['POST'])
# def get_similar_images():
#     # Load the required pickle files and CSV file
#     ft_dict = pkl.load(open('feature_dict.pkl', 'rb'))
#     train = pkl.load(open('train_dict.pkl', 'rb'))
#     # Get the uploaded image file

#     img = request.files['image']
#     print(img)
#     from PIL import Image

#     # img_file = "/content/Tourist_attraction_5718.jpg"       # write the image file name
#     img = Image.open(img)
#     img = img.resize((224, 224))

#     # img.show()
#     # Call the get_sim_img function
#     res_df = get_sim_img(img)
#     res_df = res_df[:30]
#     res_df = res_df.drop(my_list,axis = 1)
#     temp = travel_dataframe.drop(my_list,axis = 1)

#     # travel_dataframe = travel_dataframe.iloc[res_df['place_id']]
#     temp = temp.loc[temp['place_id'].isin(res_df['place_id'])]
#     temp = temp.loc[res_df.index]
#     temp = temp.drop_duplicates(subset='title')
#     # Convert the output DataFrame to JSON and return it
#     return jsonify(temp.to_dict(orient='records'))

# def extract(img):
#   x = image.img_to_array(img)
#   x = np.expand_dims(x, axis=0)
#   x = preprocess_input(x)
#   feature = model.predict(x)[0]
#   return feature / np.linalg.norm(feature)

# def get_sim_img(img):
#     res = []
#     ft = extract(img)
#     for fl, train_ft in ft_dict.items():
#         sim = 1 - cosine(train_ft[1], ft)
#         res.append([train_ft[0], train[fl][1], sim, train[fl][2]])
#     res.sort(key=operator.itemgetter(2, 3), reverse=True)
#     if len(res) > 50:
#         pids = [res[i][0] for i in range(50)]
#         res = [[res[i][0], res[i][1]] for i in range(50)]
#     else:
#         pids = [res[i][0] for i in range(len(res))]
#         res = [[res[i][0], res[i][1]] for i in range(len(res))]
#     df2 = travel_dataframe.loc[travel_dataframe['place_id'].isin(pids)]
#     # res_df = df2[['place_id', 'title', 'city', 'state', 'description', 'imageUrls_0']].copy()
#     # res_df.loc[:, 'imageUrls_0'] = [res[i][1] for i in range(len(res_df))]
#     return df2

#     # Convert the output DataFrame to JSON and return it
#     return jsonify(res_df.to_dict(orient='records'))
    

if __name__ == '__main__':
    app.run(debug=True)
  