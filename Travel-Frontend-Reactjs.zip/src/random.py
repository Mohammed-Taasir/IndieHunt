import os
import pandas as pd
img_dir_path=input("enter image dir path:")
files_list=os.listdir(img_dir_path)
ex_path=input("enter excel sheet path:")
df=pd.read_excel(ex_path)
for fl in files_list:
    